/**
 *
 */
package org.bukkit.entity;

/**
 * Represents a Flying Entity.
 *
 * @author Cogito
 *
 */
public interface Flying extends LivingEntity {}
