package org.bukkit.entity;

/**
 * Represents a Fish.
 */
public interface Fish extends Projectile {}
