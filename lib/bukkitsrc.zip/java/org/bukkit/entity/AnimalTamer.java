package org.bukkit.entity;

public interface AnimalTamer {}
